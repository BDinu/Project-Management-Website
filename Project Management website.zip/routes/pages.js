const express = require('express');
const router = express.Router();
router.get('/', (req, res) => {
res.render('paginastart');
})
router.get('/register',(req,res) =>{
    res.render('register');
    })
router.get('/login',(req,res) =>{
    res.render('login');
})
router.get('/home',(req,res) =>{
    res.render('home');
})
router.get('/dashb', (req,res) =>{
    res.render('dashb');
})
router.get('/echipe',(req,res) =>{
    res.render('echipe');})
router.get('/task',(req,res) =>{
    res.render('task');
})
router.get('/profil',(req,res) =>{
    res.render('profil');})

module.exports = router;