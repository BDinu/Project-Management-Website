const mysql = require("mysql");
const express = require('express');
const path = require('path');
const app = express();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');



const bd = mysql.createConnection({
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE,
})

exports.register = (req, res) =>{
    console.log(req.body);
    const username = req.body.name;
    const email = req.body.email;
    const password = req.body.password;
    const passwordconf = req.body.passwordconf;
    const cod_profesor = req.body.cod_profesor;


    // Verificarea dacă username-ul și parola sunt furnizate
    if (!username || !password || !email || !passwordconf) {
        return res.render('register', { message: 'Toate campurile trebuie completate' }); 
    }

    let rol = "student";
    if (cod_profesor === "55555") {
        rol = "profesor";
    }
    
    //Selectam coloana email din tabelul users pentru SQL injections
    bd.query('SELECT email FROM users WHERE email = ?', [email], async (error,result) =>{
        if(error){
            console.log(error)}
        if(result && result.length > 0){
            return res.render('register', { message: "Emailul este deja folosit" });}
        else if(password !== passwordconf){
            return res.render('register', { message: 'Parolele nu se potrivesc' });}
        
        bd.query('INSERT INTO users SET ?', {username: username, email: email, password: password, rol: rol }, (error, results) =>{
            if(error){
                console.log(error);
            }
            else{
                console.log(results);
                return res.render('register',{ message: 'User înregistrat' });
            }
        });
    });
    
}

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

exports.login = (req, res) => {
    console.log(req.body);
    const username = req.body.name?.trim();
    const password = req.body.password;
  
    // Verificarea dacă username-ul și parola sunt furnizate
    if (!username || !password) {
        return res.render('login', { message: 'Username si parola trebuie inserate' }); 
    }
    
    bd.query('SELECT * FROM users WHERE username = ?', [username], async (error, results) => {
        if (error) {
            console.error(error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }
  
        if (results.length === 0) {
            // Utilizatorul nu există
            return res.render('login', { message: 'Userul nu a fost gasit' });
        }
  
        const user = results[0];
        
        // Verificarea dacă parola furnizată se potrivește cu parola stocată în baza de date
        if (password === user.password) {
            // Autentificare reușită

            // Salvare user_id în sesiune
            req.session.userId = user.user_id;
            req.session.username = user.username;
            console.log(user.user_id);
            console.log(user,username);

            return res.render('dashb');
        } else {
            // Parolă incorectă
            return res.render('login', { message: 'Parola incorecta' });
        }
    });
};



exports.logout = (req, res) => {
    res.redirect('/login');
};

exports.countuser = (req, res) => {
    // Interogare pentru a număra numărul de utilizatori
    bd.query('SELECT COUNT(*) AS totalCount FROM users', (error, results) => {
        if (error) {
            console.error('Error counting users:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        // Extrage numărul total de utilizatori din rezultate
        const totalCount = results[0].totalCount;

        // Returnează numărul de utilizatori ca răspuns JSON
        res.status(200).json({ totalCount });
    });
};

// Înlocuiește conținutul actual al funcției fillStudentsList cu următorul cod:
exports.lista = (req, res) => {
    // Interogare pentru a selecta utilizatorii care sunt studenți
    bd.query('SELECT username FROM users WHERE rol = true',(error, results) => {
        // Verificăm dacă există erori în interogare
        if (error) {
            console.error(error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }
        
        // Verificăm dacă s-au găsit studenți
        if (results.length === 0) {
            return res.status(404).json({ message: 'Nu s-au găsit studenți' });
        }
        // Dacă s-au găsit studenți, îi returnăm către client
        res.status(200).json({ students: results });
        
    });

};

// Funcție pentru a crea o echipă nouă
exports.echipa = (req, res) => {
    const nume_echipa = req.body.nume_echipa;
    const membri = req.body.membri;
    const creatorId = req.session.userId; // ID-ul utilizatorului care face cererea de creare a echipei

    console.log("Nume echipa:", nume_echipa);
    console.log("Membri echipa:", membri);
    console.log("Creator echipa:", creatorId); // Afișează ID-ul utilizatorului care a creat echipa

    if (!nume_echipa || !membri || membri.length === 0) {
        return res.status(400).json({ message: 'Numele echipei și membrii trebuie furnizate' });
    }

    bd.query('INSERT INTO teams (nume_echipa, membri, creator_id) VALUES (?, ?, ?)', [nume_echipa, JSON.stringify(membri), creatorId], (error, result) => {
        if (error) {
            console.error('Error creating team:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        const teamId = result.insertId;

        // Actualizarea utilizatorilor cu noua echipă și actualizarea team_id
        bd.query('UPDATE users SET team_id = CONCAT(team_id, ?) WHERE username IN (?)', [',' + teamId, membri], (error, results) => {
            if (error) {
                console.error('Error updating team members:', error);
                return res.status(500).json({ message: 'Internal Server Error' });
            }
            
            res.status(201).json({ message: 'Echipa a fost creată cu succes', teamId });
        });
    });
};



exports.afisare= (req, res) => {
    const userId = req.session.userId;
    console.log('Am ajuns aici ', userId);

    // Interogăm baza de date pentru a obține detalii despre echipele utilizatorului
    bd.query('SELECT nume_echipa, membri FROM teams WHERE EXISTS (SELECT 1 FROM users WHERE users.user_id = ? AND teams.membri LIKE CONCAT("%", users.username, "%"))', [userId], (error, results) => {
        if (error) {
            console.error('Eroare la interogarea bazei de date:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }
    
        // Returnăm rezultatele ca un răspuns JSON
        res.status(200).json({ teams: results });
    });

}

exports.afisareprim = (req, res) => {
    const userId = req.session.userId; // Obținem userId-ul utilizatorului din sesiune

    // Interogăm baza de date pentru a obține detalii despre echipele create de utilizator
    bd.query('SELECT nume_echipa, membri FROM teams WHERE creator_id = ?', [userId], (error, results) => {
        if (error) {
            console.error('Eroare la interogarea bazei de date:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }
    
        // Returnăm rezultatele ca un răspuns JSON
        res.status(200).json({ teams: results });
    });
}



exports.exit_team = (req, res) => {
    const userId = req.session.userId; // Obține userId-ul utilizatorului din sesiune
    const nume_echipa = req.body.nume_echipa; // Obține numele echipei din corpul cererii

    // Verifică dacă userId și nume_echipa sunt furnizate
    if (!userId || !nume_echipa) {
        return res.status(400).json({ message: 'userId și nume_echipa trebuie furnizate' });
    }

    // Execută query-ul pentru a actualiza coloana "team_id" din tabela "users" și a șterge numărul id-ului echipei din această coloană
    bd.query(
        'UPDATE users SET team_id = REPLACE(team_id,(SELECT id FROM teams WHERE nume_echipa = ?), "") WHERE user_id = ?',
        [nume_echipa, userId],
        (error, results) => {
            if (error) {
                console.error('Eroare la părăsirea echipei:', error);
                return res.status(500).json({ message: 'Internal Server Error' });
            }

            // Verifică dacă actualizarea a avut succes
            if (results.affectedRows > 0) {
                // Dacă actualizarea a avut succes, execută query-ul pentru a actualiza coloana "membri" din tabela "teams"
                bd.query(
                    'UPDATE teams SET membri = REPLACE(membri, (SELECT username FROM users WHERE user_id = ?), "") WHERE nume_echipa = ?',
                    [userId, nume_echipa],
                    (error, results) => {
                        if (error) {
                            console.error('Eroare la actualizarea membrilor echipei:', error);
                            return res.status(500).json({ message: 'Internal Server Error' });
                        }

                        // Verifică dacă actualizarea a avut succes și trimite un răspuns corespunzător
                        if (results.affectedRows > 0) {
                            res.status(200).json({ message: 'Ai părăsit echipa cu succes' });
                        } else {
                            res.status(404).json({ message: 'Nu ai putut părăsi echipa' });
                        }
                    }
                );
            } else {
                res.status(404).json({ message: 'Nu ai putut părăsi echipa' });
            }
        }
    );
};


// Funcție pentru a crea un task nou
exports.createTask = (req, res) => {
    const { task, assignee } = req.body;
    const author = req.session.userId; // Presupunând că ID-ul utilizatorului logat este disponibil în req.user.id


    // Însertăm datele în baza de date
    bd.query('INSERT INTO tasks (task, assignee, author) VALUES (?, ?, ?)', [task, assignee, author], (error, results) => {
        if (error) {
            console.error('Eroare la crearea taskului:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }
        res.status(201).json({ message: 'Task creat cu succes' });
    });
};



// Funcție pentru a șterge un task
exports.deleteTask = (req, res) => {
    const { id } = req.body;

    if (!id) {
        return res.status(400).json({ message: 'Id-ul taskului este necesar' });
    }

    bd.query('DELETE FROM tasks WHERE id = ?', [id], (error, results) => {
        if (error) {
            console.error('Eroare la ștergerea taskului:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'Taskul nu a fost găsit' });
        }
        res.status(200).json({ message: 'Task șters cu succes' });
    });
};

exports.deleteTeam = (req, res) => {
    const { nume_echipa } = req.body;
    const creator_id = req.session.userId; // Presupunem că ID-ul utilizatorului este disponibil în req.session.userId

    console.log('Request to delete team with name:', nume_echipa, 'by user:', creator_id); // Adaugă un mesaj de logare

    if (!nume_echipa || !creator_id) {
        return res.status(400).json({ message: 'Numele echipei și ID-ul creatorului sunt necesare' });
    }

    // Query pentru a șterge echipa pe baza numelui echipei și a ID-ului creatorului
    const sqlDeleteTeam = 'DELETE FROM teams WHERE nume_echipa = ? AND creator_id = ?';

    bd.query(sqlDeleteTeam, [nume_echipa, creator_id], (error, results) => {
        if (error) {
            console.error('Eroare la ștergerea echipei:', error);
            return res.status(500).json({ message: 'Eroare internă a serverului' });
        }
        if (results.affectedRows === 0) {
            console.log('Echipa nu a fost găsită:', nume_echipa, creator_id); // Adaugă un mesaj de logare
            return res.status(404).json({ message: 'Echipa nu a fost găsită' });
        }
        console.log('Echipa ștearsă cu succes:', nume_echipa); // Adaugă un mesaj de logare
        res.status(200).json({ message: 'Echipa ștearsă cu succes' });
    });
};




exports.getTask = (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        return res.status(400).json({ message: 'User not logged in' });
    }

    const query = `
        SELECT t.id, t.task, u.username AS author, t.status
        FROM tasks t
        JOIN users u ON t.author = u.user_id
        WHERE t.assignee = (SELECT username FROM users WHERE user_id = ?)
    `;

    bd.query(query, [userId], (error, results) => {
        if (error) {
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        res.status(200).json({ tasks: results });
    });
};


// Route pentru actualizarea statusului unui task
exports.updateTaskStatus = (req, res) => {
    const { taskId, status } = req.body;

    if (!taskId || !status) {
        return res.status(400).json({ message: 'Toate câmpurile sunt necesare' });
    }

    bd.query('UPDATE tasks SET status = ? WHERE id = ?', [status, taskId], (error, results) => {
        if (error) {
            console.error('Eroare la actualizarea statusului task-ului:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }
        res.status(200).json({ message: 'Statusul task-ului actualizat cu succes' });
    });
};


exports.getYourTasks = (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        return res.status(400).json({ message: 'User not logged in' });
    }

    const query = `
        SELECT t.id, t.task, u.username AS author, t.status
        FROM tasks t
        JOIN users u ON t.author = u.user_id
        WHERE t.assignee = (SELECT username FROM users WHERE user_id = ?)
    `;

    bd.query(query, [userId], (error, results) => {
        if (error) {
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        res.status(200).json({ tasks: results });
    });
};

exports.getCreatedTasks = (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        return res.status(400).json({ message: 'User not logged in' });
    }

    const query = `
        SELECT t.id, t.task, u.username AS assignee, t.status
        FROM tasks t
        JOIN users u ON t.assignee = u.username
        WHERE t.author = ?
    `;

    bd.query(query, [userId], (error, results) => {
        if (error) {
            console.error('Error fetching created tasks:', error);
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        res.status(200).json({ tasks: results });
    });
};



exports.getUserDetails = (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        return res.status(400).json({ message: 'User not logged in' });
    }

    bd.query('SELECT username, email, password FROM users WHERE user_id = ?', [userId], (error, results) => {
        if (error) {
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.status(200).json({ user: results[0] });
    });
};

exports.deleteAccount = (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        return res.status(400).json({ message: 'User not logged in' });
    }

    bd.query('DELETE FROM users WHERE user_id = ?', [userId], (error, results) => {
        if (error) {
            return res.status(500).json({ message: 'Internal Server Error' });
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        req.session.destroy((err) => {
            if (err) {
                return res.status(500).json({ message: 'Failed to log out user' });
            }

            res.status(200).json({ message: 'Account deleted successfully' });
        });
    });
};
