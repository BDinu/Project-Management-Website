const express = require('express');
const authController = require('../controllers/auth');
const router = express.Router();


router.post('/register', authController.register);
router.post('/login', authController.login);
router.get('/logout', authController.logout);


router.get('/lista', authController.lista);


router.post('/countuser', authController.countuser); // Contorizează utilizatorii
router.post('/echipa', authController.echipa); // Creează o echipă
router.post('/afisare', authController.afisare); // Afisare
router.post('/afisareprim', authController.afisareprim); // Afisare
router.post('/exit_team',authController.exit_team); //Iesire echipa

router.delete('/deleteTeam', authController.deleteTeam);


router.get('/getTask', authController.getTask); // Obține toate taskurile
router.get('/getCreatedTasks', authController.getCreatedTasks); // Taskuri create
router.get('/getYourTasks', authController.getYourTasks); // Taskurile de facut
router.post('/createTask', authController.createTask); // Creează un task
router.delete('/deleteTask', authController.deleteTask); // Șterge un task
router.post('/updateTaskStatus', authController.updateTaskStatus);

router.get('/getUserDetails', authController.getUserDetails);
router.post('/deleteAccount', authController.deleteAccount);

module.exports = router;
